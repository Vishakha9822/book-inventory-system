
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Book1 } from './models/book.model'; 

export interface Book {
  id?: number;
  title: string;
  author: string;
  genre: string;
  publication_date: string;
  isbn: string;
}

@Injectable({
  providedIn: 'root'
})
export class BookService {
  private apiUrl = 'http://localhost:3000/books'; // Your API endpoint

  constructor(private http: HttpClient) {}

  addBook(book: Book): Observable<Book> {
    console.log(book)
    return this.http.post<Book>(this.apiUrl, book);
  }

  getBooks(): Observable<Book1[]> {
    return this.http.get<Book1[]>(this.apiUrl);
  }
  
}
