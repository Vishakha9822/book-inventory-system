import { Component, OnInit } from '@angular/core';
import { BookService, Book } from '../book.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-books-list',
  templateUrl: './books-list.component.html',
  styleUrls: ['./books-list.component.css']
})
export class BooksListComponent implements OnInit {
  books: Book[] = [];
  filteredBooks: Book[] = [];

  constructor(private bookService: BookService) {}

  ngOnInit(): void {
    this.fetchBooks();
  }

  fetchBooks(): void {
    this.bookService.getBooks().subscribe(
      (data: Book[]) => {
        this.books = data;
      },
      (error: any) => {
        console.error('Error fetching books:', error);
      }
    );
  }

  applyFilter(filterValues: any): void {
    const { title, author, genre, publication_date } = filterValues;

    this.filteredBooks = this.books.filter(book => {
      return (
        (!title || book.title.toLowerCase().includes(title.toLowerCase())) &&
        (!author || book.author.toLowerCase().includes(author.toLowerCase())) &&
        (!genre || book.genre.toLowerCase().includes(genre.toLowerCase())) &&
        (!publication_date || book.publication_date === publication_date) // For exact match
      );
    });
  }

  exportToCSV(): void {
    const csvData = this.convertToCSV(this.books);
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'books.csv');
    link.click();
  }

  private convertToCSV(data: Book[]): string {
    const headers = 'Title,Author,Genre,Publication Date,ISBN\n';
    const rows = data.map(book => 
      `${book.title},${book.author},${book.genre},${book.publication_date},${book.isbn}`
    ).join('\n');
    return headers + rows;
  }

  exportToJSON(): void {
    const jsonData = JSON.stringify(this.books, null, 2);
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'books.json');
    link.click();
  }
}

