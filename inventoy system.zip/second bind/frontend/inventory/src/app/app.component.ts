
import { Component } from '@angular/core';
import { Book } from './book.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  books: Book[] = [];

  onBookAdded(book: Book) {
    console.log(book);
    this.books.push(book);
  }
}
