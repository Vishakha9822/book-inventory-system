import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { BookService, Book } from '../book.service';

@Component({
  selector: 'app-filter-book',
  templateUrl: './filter-book.component.html',
  styleUrls: ['./filter-book.component.css']
})
export class FilterBookComponent implements OnInit {
  books: Book[] = [];
  filteredBooks: Book[] = [];
  filterForm: FormGroup;

  constructor(private bookService: BookService, private fb: FormBuilder) {
    this.filterForm = this.fb.group({
      title: [''],
      author: [''],
      genre: [''],
      publication_date: ['']
    });
  }

  ngOnInit(): void {
    this.fetchBooks(); 
  }

  fetchBooks(): void {
    this.bookService.getBooks().subscribe(
      (data: Book[]) => {
        this.books = data;
        this.filteredBooks = data; 
      },
      (error) => {
        console.error('Error fetching books:', error);
      }
    );
  }

  applyFilter(): void {
    const { title, author, genre, publication_date } = this.filterForm.value;

    this.filteredBooks = this.books.filter(book => {
      return (
        (!title || book.title.toLowerCase().includes(title.toLowerCase())) &&
        (!author || book.author.toLowerCase().includes(author.toLowerCase())) &&
        (!genre || book.genre.toLowerCase().includes(genre.toLowerCase())) &&
        (!publication_date || book.publication_date === publication_date) // For exact match
      );
    });

  }
}
