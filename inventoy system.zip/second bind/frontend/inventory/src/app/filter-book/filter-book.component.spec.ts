import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FilterBookComponent } from './filter-book.component';

describe('FilterBookComponent', () => {
  let component: FilterBookComponent;
  let fixture: ComponentFixture<FilterBookComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FilterBookComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FilterBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
