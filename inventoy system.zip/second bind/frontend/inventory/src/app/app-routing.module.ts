import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BooksListComponent } from './books-list/books-list.component'; 
import { AddBookComponent } from './add-book/add-book.component'; 
import { FilterBookComponent } from './filter-book/filter-book.component';


const routes: Routes = [
  { path: '', redirectTo: '/books', pathMatch: 'full' }, // Redirect to books list
  { path: 'books', component: BooksListComponent },
  { path: 'add-book', component: AddBookComponent },
  { path: 'filter-books', component: FilterBookComponent },
  // Add more routes as needed
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
