export interface Book1 {
    id?: number;
    title: string;
    author: string;
    genre: string;
    publication_date: string; 
    isbn: string;
  }
  