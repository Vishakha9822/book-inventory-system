
import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BookService, Book } from '../book.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent {
  @Output() bookAdded = new EventEmitter<Book>(); // Define the EventEmitter

  bookForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private bookService: BookService,
    private router: Router
  ) {
    // Initialize the form with validation
    this.bookForm = this.fb.group({
      title: ['', Validators.required],
      author: ['', Validators.required],
      genre: ['', Validators.required],
      publication_date: ['', Validators.required],
      isbn: ['', [Validators.required, Validators.pattern('^[0-9]{13}$')]] // Add a regex pattern for ISBN
    });
  }

  // Method to handle form submission
  onSubmit() {
    if (this.bookForm.valid) {
      const newBook: Book = this.bookForm.value;

      this.bookService.addBook(newBook).subscribe(
        (response: any) => {
          console.log('Book added successfully:', response);
          this.router.navigate(['/books']);
        },
        (error: any) => {
          console.error('Error adding book:', error);
        }
      );
    } else {
      console.error('Form is invalid');
    }
  }
}
