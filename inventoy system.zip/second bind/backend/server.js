// server.js
const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const { Parser } = require('json2csv');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

// MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'book_inventory',
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to MySQL database.');
});

// Add new book
app.post('/books', (req, res) => {
    const { title, author, genre, publication_date, isbn } = req.body;
    const query = 'INSERT INTO Inventory (title, author, genre, publication_date, isbn) VALUES (?, ?, ?, ?, ?)';
    connection.query(query, [title, author, genre, publication_date, isbn], (err, results) => {
        if (err) return res.status(500).json(err);
        res.status(201).json({ id: results.insertId, title, author, genre, publication_date, isbn });
    });
});

app.get('/books', (req, res) => {
  const query = 'SELECT * FROM Inventory';
  connection.query(query, (err, results) => {
      if (err) {
          console.error('Error fetching books:', err);
          return res.status(500).json({ error: 'An error occurred while fetching books' });
      }
      res.status(200).json(results);
  });
});

// Filter books
app.get('/books', (req, res) => {
  const { title, author, genre, publication_date, isbn } = req.query;
  let query = 'SELECT * FROM Inventory WHERE 1=1';
  const params = [];

  if (title) {
    query += ' AND title LIKE ?';
    params.push(`%${title}%`);
  }
  if (author) {
    query += ' AND author LIKE ?';
    params.push(`%${author}%`);
  }
  if (genre) {
    query += ' AND genre LIKE ?';
    params.push(`%${genre}%`);
  }
  if (publication_date) {
    query += ' AND publication_date = ?';
    params.push(publication_date);
  }

  if (isbn) {
    query += ' AND isbn = ?';
    params.push(isbn);
  }

  connection.query(query, params, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// Export data as CSV
app.get('/export', (req, res) => {
  connection.query('SELECT * FROM Inventory', (err, results) => {
    if (err) return res.status(500).json(err);
    const csv = new Parser().parse(results);
    res.header('Content-Type', 'text/csv');
    res.attachment('books.csv');
    res.send(csv);
  });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});


